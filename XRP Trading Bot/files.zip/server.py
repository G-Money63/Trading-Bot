"""
XRP Semi-Auto Grid Bot — Cloud Server
======================================
Grid Bot watches price levels every 15s and queues PENDING signals.
The dashboard shows each signal with CONFIRM / SKIP buttons.
Only confirmed signals execute — paper or live via Coinbase Advanced.

Endpoints:
  GET  /                       → dashboard
  GET  /api/latest             → market snapshot
  GET  /api/history            → price history
  GET  /api/bot/state          → full bot + grid state
  POST /api/bot/config         → save grid config
  POST /api/bot/start          → start watching
  POST /api/bot/stop           → stop watching
  POST /api/bot/confirm        → confirm a pending signal → execute
  POST /api/bot/skip           → skip a pending signal
  GET  /health
"""

import asyncio, json, os, statistics, threading, time, logging, urllib.request, uuid, hmac, hashlib
from collections import deque
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
import websockets

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────
PORT            = int(os.environ.get("PORT", 8080))
POLL_INTERVAL   = 15
HISTORY_MAXLEN  = 200
OBI_THRESHOLD   = 0.15
OBI_SMOOTH_N    = 4
DEPTH_LEVELS    = 20
XRPL_WS         = "wss://xrplcluster.com"
BINANCE_REST    = "https://api.binance.com/api/v3/depth?symbol=XRPUSDT&limit=20"
BITSTAMP_ISSUER = "rvYAfWj5gh67oV6fW32ZzP3Aw4Eubs59B"
CB_API_KEY      = os.environ.get("CB_API_KEY", "")
CB_API_SECRET   = os.environ.get("CB_API_SECRET", "")
CB_BASE_URL     = "https://api.coinbase.com"
PRODUCT_ID      = "XRP-USD"

# ─── Market State ─────────────────────────────────────────────────────────────
history         = deque(maxlen=HISTORY_MAXLEN)
latest_snapshot = {}
state_lock      = threading.Lock()

# ─── Scaler ───────────────────────────────────────────────────────────────────
class MinMaxScaler:
    def __init__(self, w=40):
        self.buf = deque(maxlen=w)
    def fit_transform(self, v):
        self.buf.append(v)
        lo, hi = min(self.buf), max(self.buf)
        return 0.5 if hi == lo else (v - lo) / (hi - lo)

obi_scaler    = MinMaxScaler()
spread_scaler = MinMaxScaler()
depth_scaler  = MinMaxScaler()

# ─── Grid Bot State ───────────────────────────────────────────────────────────
grid = {
    "running":       False,
    "mode":          "paper",       # "paper" | "live"
    "config": {
        "upper":         2.50,      # default upper price USD
        "lower":         1.80,      # default lower price USD
        "levels":        10,        # number of grid lines
        "amount_usd":    50.0,      # USD per grid order
        "stop_loss_pct": 5.0,
        "take_profit_pct": 15.0,
    },
    # Derived grid lines — recomputed when config changes
    "grid_lines":    [],            # list of price levels
    # Which levels have open buy/sell orders (level_index: order_dict)
    "buy_orders":    {},
    "sell_orders":   {},
    # Pending signals waiting for user confirm/skip
    "pending":       [],            # list of signal dicts
    # Confirmed executed trades
    "trade_log":     deque(maxlen=200),
    # Portfolio
    "portfolio": {
        "cash_usd":      1000.0,
        "xrp_held":      0.0,
        "avg_entry":     0.0,
        "realized_pnl":  0.0,
    },
    "last_checked_band": -1,
}
grid_lock = threading.Lock()

# ─── Grid Math ────────────────────────────────────────────────────────────────
def build_grid_lines(upper, lower, levels):
    """Return evenly spaced price levels including upper and lower bounds."""
    if upper <= lower or levels < 2:
        return []
    step = (upper - lower) / levels
    return [round(lower + i * step, 6) for i in range(levels + 1)]

def recompute_grid():
    with grid_lock:
        cfg = grid["config"]
        lines = build_grid_lines(cfg["upper"], cfg["lower"], cfg["levels"])
        grid["grid_lines"] = lines
        grid["buy_orders"]  = {}
        grid["sell_orders"] = {}
        grid["last_checked_band"] = -1
        log.info(f"Grid recomputed: {len(lines)} lines  ${cfg['lower']}–${cfg['upper']}")

# ─── Signal Builder ───────────────────────────────────────────────────────────
def make_signal(side, price, level_idx, level_low, level_high, snap):
    amount = grid["config"]["amount_usd"]
    xrp_qty = round(amount / price, 4)
    obi   = snap.get("obi", 0)
    bull  = snap.get("bull_score", 0.5)
    # Signal confidence based on OBI direction matching trade side
    if side == "BUY":
        confidence = "HIGH" if obi > 0.1 and bull > 0.55 else "MEDIUM" if obi > -0.05 else "LOW"
        conf_color = "#00ff88" if confidence == "HIGH" else "#ffcc00" if confidence == "MEDIUM" else "#ff8800"
    else:
        confidence = "HIGH" if obi < -0.1 and bull < 0.45 else "MEDIUM" if obi < 0.05 else "LOW"
        conf_color = "#00ff88" if confidence == "HIGH" else "#ffcc00" if confidence == "MEDIUM" else "#ff8800"

    stop_price   = round(price * (1 - grid["config"]["stop_loss_pct"] / 100), 6)
    target_price = round(price * (1 + grid["config"]["take_profit_pct"] / 100), 6)

    return {
        "id":           str(uuid.uuid4())[:8],
        "side":         side,
        "price":        round(price, 6),
        "xrp_qty":      xrp_qty,
        "usd_amount":   round(amount, 2),
        "level_idx":    level_idx,
        "level_low":    round(level_low, 6),
        "level_high":   round(level_high, 6),
        "level_label":  f"Level {level_idx + 1} of {grid['config']['levels']}",
        "stop_price":   stop_price,
        "target_price": target_price,
        "confidence":   confidence,
        "conf_color":   conf_color,
        "obi":          round(obi, 4),
        "bull_score":   round(bull, 3),
        "signal":       snap.get("signal", "—"),
        "signal_color": snap.get("signal_color", "#ffcc00"),
        "ts":           datetime.now(timezone.utc).isoformat(),
        "status":       "pending",
        "mode":         grid["mode"],
    }

# ─── Grid Engine ──────────────────────────────────────────────────────────────
def run_grid_tick(snap):
    if not grid["running"]:
        return
    price = snap.get("mid_price", 0)
    if not price:
        return

    with grid_lock:
        lines = grid["grid_lines"]
        if len(lines) < 2:
            return
        cfg   = grid["config"]
        lo    = cfg["lower"]
        hi    = cfg["upper"]

        # Check stop loss
        pf = grid["portfolio"]
        if pf["xrp_held"] > 0 and pf["avg_entry"] > 0:
            drop = (pf["avg_entry"] - price) / pf["avg_entry"] * 100
            if drop >= cfg["stop_loss_pct"]:
                sig = make_signal("SELL", price, -1, price, price, snap)
                sig["level_label"] = f"🛑 STOP LOSS ({drop:.1f}% drop)"
                sig["confidence"]  = "STOP LOSS"
                sig["conf_color"]  = "#ff3355"
                if not any(p["id"] == sig["id"] for p in grid["pending"]):
                    grid["pending"].append(sig)
                    log.info(f"STOP LOSS signal queued at ${price:.5f}")
                return

        # Out of range — no grid action
        if price < lo or price > hi:
            return

        # Find which band (gap between two grid lines) the price is in
        band = -1
        for i in range(len(lines) - 1):
            if lines[i] <= price < lines[i + 1]:
                band = i
                break
        if band < 0:
            return

        # Only generate a new signal if we've moved to a different band
        if band == grid["last_checked_band"]:
            return

        prev_band = grid["last_checked_band"]
        grid["last_checked_band"] = band

        # Skip on first tick
        if prev_band < 0:
            return

        # Determine direction of price movement
        moved_down = band < prev_band
        moved_up   = band > prev_band

        already_pending_sides = {p["side"] for p in grid["pending"] if p["status"] == "pending"}
        already_bought  = band in grid["buy_orders"]
        already_sold    = band in grid["sell_orders"]

        # Price dropped into this band → BUY opportunity at the lower line
        if moved_down and not already_bought and "BUY" not in already_pending_sides:
            buy_price = lines[band]         # bottom of this band
            sig = make_signal("BUY", buy_price, band, lines[band], lines[band+1], snap)
            grid["pending"].append(sig)
            log.info(f"BUY signal queued: level {band+1}  @${buy_price:.5f}  conf={sig['confidence']}")

        # Price rose into this band → SELL opportunity at the upper line
        if moved_up and pf["xrp_held"] > 0 and not already_sold and "SELL" not in already_pending_sides:
            sell_price = lines[band + 1]    # top of this band
            sig = make_signal("SELL", sell_price, band, lines[band], lines[band+1], snap)
            grid["pending"].append(sig)
            log.info(f"SELL signal queued: level {band+1}  @${sell_price:.5f}  conf={sig['confidence']}")

# ─── Trade Execution ──────────────────────────────────────────────────────────
def execute_paper(sig):
    with grid_lock:
        pf    = grid["portfolio"]
        side  = sig["side"]
        price = sig["price"]
        if side == "BUY":
            usd = min(sig["usd_amount"], pf["cash_usd"])
            if usd < 1:
                return False, "Insufficient cash"
            qty = usd / price
            total_xrp = pf["xrp_held"] + qty
            pf["avg_entry"] = (pf["avg_entry"] * pf["xrp_held"] + price * qty) / total_xrp if total_xrp else price
            pf["xrp_held"] += qty
            pf["cash_usd"] -= usd
            sig["xrp_qty"] = round(qty, 4)
            sig["usd_amount"] = round(usd, 2)
            grid["buy_orders"][sig["level_idx"]] = sig
        else:
            qty = min(sig["xrp_qty"], pf["xrp_held"])
            if qty < 0.001:
                return False, "Insufficient XRP"
            usd = qty * price
            cost = qty * pf["avg_entry"]
            pnl  = usd - cost
            pf["xrp_held"]     -= qty
            pf["cash_usd"]     += usd
            pf["realized_pnl"] += pnl
            if pf["xrp_held"] < 0.001:
                pf["avg_entry"] = 0
            sig["usd_amount"] = round(usd, 2)
            sig["pnl"]        = round(pnl, 4)
            grid["sell_orders"][sig["level_idx"]] = sig
        sig["status"]    = "executed"
        sig["exec_ts"]   = datetime.now(timezone.utc).isoformat()
        grid["trade_log"].appendleft(dict(sig))
        log.info(f"[PAPER {side}] ${price:.5f} × {sig['xrp_qty']:.4f} XRP  [{sig['level_label']}]")
        return True, "ok"

def execute_live(sig):
    if not CB_API_KEY:
        return False, "No API keys"
    # Build Coinbase order
    ts  = str(int(time.time()))
    path = "/api/v3/brokerage/orders"
    if sig["side"] == "BUY":
        order_cfg = {"market_market_ioc": {"quote_size": str(round(sig["usd_amount"], 2))}}
    else:
        order_cfg = {"market_market_ioc": {"base_size": str(round(sig["xrp_qty"], 6))}}
    body_dict = {
        "client_order_id": str(uuid.uuid4()),
        "product_id":      PRODUCT_ID,
        "side":            sig["side"],
        "order_configuration": order_cfg,
    }
    body_str = json.dumps(body_dict)
    msg  = ts + "POST" + path + body_str
    sign = hmac.new(CB_API_SECRET.encode(), msg.encode(), hashlib.sha256).hexdigest()
    req  = urllib.request.Request(
        CB_BASE_URL + path,
        data=body_str.encode(),
        headers={
            "CB-ACCESS-KEY": CB_API_KEY,
            "CB-ACCESS-SIGN": sign,
            "CB-ACCESS-TIMESTAMP": ts,
            "Content-Type": "application/json",
            "User-Agent": "XRP-GridBot/1.0",
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            res = json.loads(r.read())
        if res.get("success"):
            sig["status"]    = "executed"
            sig["exec_ts"]   = datetime.now(timezone.utc).isoformat()
            sig["cb_order_id"] = res.get("order_id")
            with grid_lock:
                grid["trade_log"].appendleft(dict(sig))
            log.info(f"[LIVE {sig['side']}] Coinbase order {sig['cb_order_id']}")
            return True, res.get("order_id")
        return False, str(res)
    except Exception as e:
        log.error(f"Coinbase order failed: {e}")
        return False, str(e)

def confirm_signal(signal_id):
    with grid_lock:
        for sig in grid["pending"]:
            if sig["id"] == signal_id and sig["status"] == "pending":
                mode = grid["mode"]
                if mode == "paper":
                    ok, msg = execute_paper(sig)
                else:
                    ok, msg = execute_live(sig)
                sig["status"] = "executed" if ok else "failed"
                sig["exec_msg"] = msg
                return ok, msg
    return False, "Signal not found"

def skip_signal(signal_id):
    with grid_lock:
        for sig in grid["pending"]:
            if sig["id"] == signal_id and sig["status"] == "pending":
                sig["status"] = "skipped"
                log.info(f"Signal {signal_id} skipped")
                return True
    return False

def pending_signals():
    with grid_lock:
        return [s for s in grid["pending"] if s["status"] == "pending"]

# ─── XRPL + Binance ───────────────────────────────────────────────────────────
async def fetch_xrpl_book():
    try:
        async with websockets.connect(XRPL_WS, open_timeout=8, close_timeout=4) as ws:
            await ws.send(json.dumps({"command":"book_offers",
                "taker_gets":{"currency":"USD","issuer":BITSTAMP_ISSUER},
                "taker_pays":{"currency":"XRP"},"limit":DEPTH_LEVELS}))
            await ws.send(json.dumps({"command":"book_offers",
                "taker_gets":{"currency":"XRP"},
                "taker_pays":{"currency":"USD","issuer":BITSTAMP_ISSUER},"limit":DEPTH_LEVELS}))
            b=json.loads(await asyncio.wait_for(ws.recv(),6))
            a=json.loads(await asyncio.wait_for(ws.recv(),6))
        bids=[{"price":float(o["quality"]),"qty":float(o["TakerPays"])/1e6}
              for o in b.get("result",{}).get("offers",[]) if "quality" in o]
        asks=[{"price":float(o["quality"]),"qty":float(o["TakerGets"])/1e6}
              for o in a.get("result",{}).get("offers",[]) if "quality" in o]
        return {"source":"XRPL","bids":bids[:DEPTH_LEVELS],"asks":asks[:DEPTH_LEVELS]}
    except Exception as e:
        log.warning(f"XRPL: {e}"); return None

def fetch_binance_book():
    try:
        req=urllib.request.Request(BINANCE_REST,headers={"User-Agent":"XRP-Bot/1.0"})
        with urllib.request.urlopen(req,timeout=8) as r:
            d=json.loads(r.read())
        return {"source":"Binance",
                "bids":[{"price":float(p),"qty":float(q)} for p,q in d.get("bids",[])],
                "asks":[{"price":float(p),"qty":float(q)} for p,q in d.get("asks",[])]}
    except Exception as e:
        log.warning(f"Binance: {e}"); return None

def compute_snapshot(books):
    bids,asks,sources=[],[],[]
    for b in books:
        if b: bids.extend(b["bids"]); asks.extend(b["asks"]); sources.append(b["source"])
    if not bids or not asks: return {}
    bids.sort(key=lambda x:x["price"],reverse=True)
    asks.sort(key=lambda x:x["price"])
    best_bid=bids[0]["price"]; best_ask=asks[0]["price"]
    mid=(best_bid+best_ask)/2; spread=best_ask-best_bid; sprd_pct=spread/mid*100
    bid_vol=sum(b["qty"] for b in bids); ask_vol=sum(a["qty"] for a in asks)
    total=bid_vol+ask_vol; obi=(bid_vol-ask_vol)/total if total else 0
    depth_tiers={}
    for pct in [0.5,1.0,2.0]:
        lo=mid*(1-pct/100); hi=mid*(1+pct/100)
        depth_tiers[f"{pct}pct"]={"bid":round(sum(b["qty"] for b in bids if b["price"]>=lo),2),
                                   "ask":round(sum(a["qty"] for a in asks if a["price"]<=hi),2)}
    def vwap(orders):
        tq=sum(o["qty"] for o in orders)
        return sum(o["price"]*o["qty"] for o in orders)/tq if tq else 0
    obi_s=obi_scaler.fit_transform(obi); sprd_s=spread_scaler.fit_transform(sprd_pct)
    d_ratio=depth_tiers["1.0pct"]["bid"]/max(depth_tiers["1.0pct"]["ask"],1)
    dep_s=depth_scaler.fit_transform(d_ratio)
    bull=obi_s*0.5+dep_s*0.3+(1-sprd_s)*0.2
    if   obi> OBI_THRESHOLD    and bull>0.6: sig,col="STRONG BUY","#00ff88"
    elif obi> OBI_THRESHOLD*.5:              sig,col="BUY","#44cc77"
    elif obi<-OBI_THRESHOLD    and bull<0.4: sig,col="STRONG SELL","#ff3355"
    elif obi<-OBI_THRESHOLD*.5:              sig,col="SELL","#ee6644"
    else:                                    sig,col="HOLD","#ffcc00"
    with state_lock:
        past=[h["obi"] for h in list(history)[-OBI_SMOOTH_N:]]
    smooth=statistics.mean(past+[obi])
    return {"ts":datetime.now(timezone.utc).isoformat(),"unix":time.time(),"sources":sources,
            "mid_price":round(mid,5),"best_bid":round(best_bid,5),"best_ask":round(best_ask,5),
            "spread":round(spread,5),"spread_pct":round(sprd_pct,4),"obi":round(obi,4),
            "smooth_obi":round(smooth,4),"bid_vol":round(bid_vol,2),"ask_vol":round(ask_vol,2),
            "bid_vwap":round(vwap(bids[:10]),5),"ask_vwap":round(vwap(asks[:10]),5),
            "depth_tiers":depth_tiers,"obi_scaled":round(obi_s,3),"spread_scaled":round(sprd_s,3),
            "depth_scaled":round(dep_s,3),"bull_score":round(bull,3),"signal":sig,"signal_color":col,
            "top_bids":bids[:8],"top_asks":asks[:8]}

async def poll_loop():
    log.info(f"Polling every {POLL_INTERVAL}s …")
    while True:
        t0=time.time()
        try:
            xrpl=await fetch_xrpl_book()
            bnb=await asyncio.get_event_loop().run_in_executor(None,fetch_binance_book)
            snap=compute_snapshot([b for b in [xrpl,bnb] if b])
            if snap:
                with state_lock:
                    history.append(snap)
                    global latest_snapshot; latest_snapshot=snap
                run_grid_tick(snap)
        except Exception as e:
            log.error(f"Poll: {e}")
        await asyncio.sleep(max(0,POLL_INTERVAL-(time.time()-t0)))

# ─── State Serializer ─────────────────────────────────────────────────────────
def full_state():
    with grid_lock:
        snap  = latest_snapshot
        price = snap.get("mid_price", 0)
        pf    = grid["portfolio"]
        xrp_v = pf["xrp_held"] * price
        unreal= (price - pf["avg_entry"]) * pf["xrp_held"] if pf["avg_entry"] else 0
        cfg   = grid["config"]
        lines = grid["grid_lines"]
        # Build enriched grid lines for visualisation
        grid_vis = []
        for i, lp in enumerate(lines):
            has_buy  = i in grid["buy_orders"]
            has_sell = i in grid["sell_orders"]
            grid_vis.append({
                "index": i,
                "price": lp,
                "has_buy":  has_buy,
                "has_sell": has_sell,
            })
        return {
            "running":   grid["running"],
            "mode":      grid["mode"],
            "config":    cfg,
            "grid_lines": grid_vis,
            "pending":   [s for s in grid["pending"] if s["status"] == "pending"],
            "trade_log": list(grid["trade_log"])[:40],
            "portfolio": {
                **pf,
                "xrp_value_usd":  round(xrp_v, 2),
                "total_value":    round(pf["cash_usd"] + xrp_v, 2),
                "unrealized_pnl": round(unreal, 4),
                "current_price":  price,
            },
            "cb_connected": bool(CB_API_KEY and CB_API_SECRET),
            "market": snap,
        }

# ─── Dashboard ────────────────────────────────────────────────────────────────
DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
<meta name="apple-mobile-web-app-title" content="XRP Grid"/>
<meta name="theme-color" content="#04080f"/>
<title>XRP Grid Bot</title>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet"/>
<style>
:root{
  --bg:#04080f;--panel:#080d18;--panel2:#0b1020;--border:#182030;--border2:#22304a;
  --text:#b8cce8;--muted:#3a5070;--green:#00e87a;--green2:#00b85f;--red:#ff2d55;
  --red2:#cc1133;--yellow:#ffd60a;--blue:#3a86ff;--cyan:#00d4ff;--orange:#ff9f0a;
  --purple:#bf5af2;--fm:'Share Tech Mono',monospace;--fh:'Orbitron',sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);font-family:var(--fm);font-size:12px}
body::before{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,212,255,.012) 3px,rgba(0,212,255,.012) 4px);pointer-events:none;z-index:900}

/* ─── Layout ─── */
.root{display:flex;flex-direction:column;min-height:100vh;padding:0 10px 20px;gap:8px;max-width:1300px;margin:0 auto}

/* ─── Header ─── */
header{display:flex;align-items:center;justify-content:space-between;padding:10px 2px;border-bottom:1px solid var(--border2)}
.logo{display:flex;align-items:center;gap:10px}
.hex{width:32px;height:32px;background:conic-gradient(from 0deg,var(--cyan),var(--green),var(--blue),var(--cyan));clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%);animation:hexspin 10s linear infinite}
@keyframes hexspin{to{transform:rotate(360deg)}}
.logo-text h1{font-family:var(--fh);font-size:13px;font-weight:900;letter-spacing:3px;background:linear-gradient(90deg,var(--cyan),var(--green));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.logo-text p{font-size:8px;color:var(--muted);letter-spacing:2px;margin-top:1px}
.hdr-right{display:flex;align-items:center;gap:14px}
.live-dot{width:8px;height:8px;border-radius:50%;background:var(--muted);transition:.3s}
.live-dot.on{background:var(--green);box-shadow:0 0 10px var(--green);animation:blink 2s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
.hdr-stat{font-size:9px;color:var(--muted);letter-spacing:1px}
.clock{font-size:10px;color:var(--cyan);letter-spacing:1px}
.cbar{height:2px;background:var(--border2);border-radius:1px;overflow:hidden;width:80px;margin-top:2px}
.cfill{height:100%;background:linear-gradient(90deg,var(--cyan),var(--green));transition:width 1s linear}

/* ─── Tabs ─── */
.tabs{display:flex;border-bottom:1px solid var(--border2);gap:0}
.tab{font-family:var(--fh);font-size:8px;letter-spacing:2px;padding:9px 16px;color:var(--muted);cursor:pointer;border-bottom:2px solid transparent;transition:all .2s;text-transform:uppercase;white-space:nowrap}
.tab.active{color:var(--cyan);border-bottom-color:var(--cyan)}
.pane{display:none;flex-direction:column;gap:8px}.pane.active{display:flex}

/* ─── Panels ─── */
.panel{background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:12px;position:relative;overflow:hidden}
.panel::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--cyan),transparent);opacity:.25}
.ptitle{font-family:var(--fh);font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--muted);margin-bottom:10px}

/* ─── Signal confirm modal ─── */
.signal-queue{display:flex;flex-direction:column;gap:8px}
.signal-card{background:var(--panel2);border-radius:6px;padding:14px;position:relative;overflow:hidden;animation:slideIn .3s ease}
@keyframes slideIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.signal-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px}
.signal-card.buy::before{background:linear-gradient(90deg,transparent,var(--green),transparent)}
.signal-card.sell::before{background:linear-gradient(90deg,transparent,var(--red),transparent)}
.signal-card.buy{border:1px solid rgba(0,232,122,.3)}
.signal-card.sell{border:1px solid rgba(255,45,85,.3)}
.sc-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.sc-badge{font-family:var(--fh);font-size:10px;font-weight:900;letter-spacing:3px;padding:4px 12px;border-radius:2px}
.sc-badge.buy{background:rgba(0,232,122,.15);color:var(--green);border:1px solid var(--green2)}
.sc-badge.sell{background:rgba(255,45,85,.15);color:var(--red);border:1px solid var(--red2)}
.sc-level{font-size:9px;color:var(--muted);letter-spacing:1px}
.sc-price{font-family:var(--fh);font-size:22px;font-weight:900;margin:6px 0}
.sc-price.buy{color:var(--green)}.sc-price.sell{color:var(--red)}
.sc-details{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:10px 0}
.sc-detail{background:var(--bg);border:1px solid var(--border);border-radius:3px;padding:7px}
.sc-detail-label{font-size:7px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;margin-bottom:3px}
.sc-detail-val{font-size:12px;color:var(--text)}
.sc-obi-row{display:flex;align-items:center;gap:8px;margin:8px 0;padding:7px;background:var(--bg);border:1px solid var(--border);border-radius:3px}
.sc-conf-badge{font-family:var(--fh);font-size:8px;letter-spacing:1px;padding:2px 8px;border-radius:2px}
.sc-actions{display:flex;gap:8px;margin-top:12px}
.btn-confirm{flex:1;background:var(--green);color:#04080f;border:none;padding:12px;border-radius:3px;font-family:var(--fh);font-size:10px;font-weight:900;letter-spacing:2px;cursor:pointer;transition:all .2s}
.btn-confirm:hover{background:var(--green2);transform:scale(1.02)}
.btn-confirm:active{transform:scale(.98)}
.btn-skip{flex:1;background:none;border:1px solid var(--border2);color:var(--muted);padding:12px;border-radius:3px;font-family:var(--fh);font-size:10px;letter-spacing:2px;cursor:pointer;transition:all .2s}
.btn-skip:hover{border-color:var(--red);color:var(--red)}
.btn-confirm.sell-confirm{background:var(--red);color:#fff}
.btn-confirm.sell-confirm:hover{background:var(--red2)}
.no-signals{text-align:center;padding:30px;color:var(--muted);font-size:10px;letter-spacing:1px}
.no-signals .pulse-ring{width:40px;height:40px;border:2px solid var(--border2);border-top-color:var(--cyan);border-radius:50%;animation:spin .8s linear infinite;margin:0 auto 12px}
@keyframes spin{to{transform:rotate(360deg)}}

/* ─── Metrics strip ─── */
.metrics{display:grid;grid-template-columns:repeat(5,1fr);gap:6px}
@media(max-width:560px){.metrics{grid-template-columns:repeat(2,1fr)}}
.mc{background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:10px;position:relative;overflow:hidden}
.mc::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--border2),transparent)}
.mc-label{font-family:var(--fh);font-size:7px;letter-spacing:2px;color:var(--muted);text-transform:uppercase;margin-bottom:4px}
.mc-val{font-family:var(--fh);font-size:17px;font-weight:900;color:var(--cyan);line-height:1;transition:color .3s}
.mc-sub{font-size:9px;color:var(--muted);margin-top:3px}
.sig-mc{background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;position:relative;overflow:hidden}
.sig-glow{position:absolute;inset:0;opacity:.07;pointer-events:none;transition:background .4s}
.sig-txt{font-family:var(--fh);font-size:13px;font-weight:900;letter-spacing:3px;transition:all .4s}

/* ─── Charts ─── */
.chart-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
@media(max-width:660px){.chart-row{grid-template-columns:1fr}}
.chart-wrap{position:relative;height:190px}
canvas{display:block;width:100%!important;height:100%!important}

/* ─── Grid visualizer ─── */
.grid-viz{position:relative;height:280px;background:var(--bg);border:1px solid var(--border);border-radius:3px;overflow:hidden;margin-top:6px}
.grid-line{position:absolute;left:0;right:0;height:1px;background:var(--border2);transition:top .5s}
.grid-line.active{background:rgba(0,212,255,.3)}
.grid-line-label{position:absolute;right:6px;font-size:8px;color:var(--muted);transform:translateY(-50%)}
.grid-line-label.has-buy{color:var(--green)}
.grid-line-label.has-sell{color:var(--red)}
.price-cursor{position:absolute;left:0;right:0;height:2px;background:var(--yellow);box-shadow:0 0 6px var(--yellow);transition:top .4s cubic-bezier(.4,0,.2,1);z-index:10}
.price-tag{position:absolute;right:6px;background:var(--yellow);color:#04080f;font-family:var(--fh);font-size:8px;font-weight:700;padding:2px 6px;border-radius:2px;transform:translateY(-50%);white-space:nowrap}
.buy-zone{position:absolute;left:0;right:0;opacity:.08;background:var(--green)}
.sell-zone{position:absolute;left:0;right:0;opacity:.08;background:var(--red)}

/* ─── Order book ─── */
.books{display:grid;grid-template-columns:1fr 1fr;gap:8px}
@media(max-width:500px){.books{grid-template-columns:1fr}}
.ob-table{width:100%;border-collapse:collapse;font-size:10px}
.ob-table th{font-family:var(--fh);font-size:6px;letter-spacing:1px;color:var(--muted);text-align:right;padding:2px 4px 5px;text-transform:uppercase}
.ob-table th:first-child{text-align:left}
.ob-table td{padding:3px 4px;text-align:right;border-bottom:1px solid rgba(24,32,48,.6);position:relative}
.ob-table td:first-child{text-align:left}
.ob-bid td{color:var(--green2)}.ob-ask td{color:var(--red2)}
.dbar{position:absolute;top:0;right:0;height:100%;opacity:.1;pointer-events:none}

/* ─── P&L cards ─── */
.pnl-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
@media(max-width:460px){.pnl-grid{grid-template-columns:1fr 1fr}}
.pnl-c{background:var(--panel2);border:1px solid var(--border);border-radius:3px;padding:8px;text-align:center}
.pnl-label{font-family:var(--fh);font-size:7px;letter-spacing:1px;color:var(--muted);margin-bottom:4px}
.pnl-val{font-size:14px;font-weight:700;font-family:var(--fh)}

/* ─── Trade log ─── */
.tlog{max-height:240px;overflow-y:auto}
.trow{display:flex;align-items:center;gap:7px;padding:5px 0;border-bottom:1px solid rgba(24,32,48,.5);flex-wrap:wrap}
.tbadge{padding:2px 6px;border-radius:1px;font-family:var(--fh);font-size:7px;letter-spacing:1px;flex-shrink:0}
.tbuy{background:rgba(0,232,122,.12);color:var(--green);border:1px solid var(--green2)}
.tsell{background:rgba(255,45,85,.12);color:var(--red);border:1px solid var(--red2)}
.tmeta{color:var(--muted);font-size:9px}

/* ─── Bot Config ─── */
.cfg-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.inp-group{display:flex;flex-direction:column;gap:3px}
.inp-label{font-family:var(--fh);font-size:7px;letter-spacing:1px;color:var(--muted);text-transform:uppercase}
.inp{background:var(--bg);border:1px solid var(--border2);border-radius:2px;color:var(--text);font-family:var(--fm);font-size:11px;padding:6px 8px;width:100%;outline:none;transition:border-color .2s}
.inp:focus{border-color:var(--cyan)}
.btn-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
.btn{font-family:var(--fh);font-size:8px;font-weight:700;letter-spacing:2px;padding:8px 16px;border-radius:2px;border:none;cursor:pointer;text-transform:uppercase;transition:all .2s;white-space:nowrap}
.btn-cyan{background:var(--cyan);color:#04080f}.btn-cyan:hover{opacity:.85}
.btn-green{background:var(--green);color:#04080f}.btn-green:hover{background:var(--green2)}
.btn-red{background:var(--red);color:#fff}.btn-red:hover{background:var(--red2)}
.btn-outline{background:none;border:1px solid var(--border2);color:var(--muted)}.btn-outline:hover{border-color:var(--cyan);color:var(--cyan)}

/* ─── Toggle ─── */
.tog-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.tog{position:relative;width:48px;height:24px}.tog input{opacity:0;width:0;height:0}
.tog-sl{position:absolute;inset:0;background:var(--border2);border-radius:12px;cursor:pointer;transition:.3s}
.tog-sl::before{content:'';position:absolute;width:18px;height:18px;left:3px;top:3px;background:var(--muted);border-radius:50%;transition:.3s}
.tog input:checked+.tog-sl{background:var(--green)}
.tog input:checked+.tog-sl::before{transform:translateX(24px);background:#04080f}
.tog-label{font-size:10px;color:var(--muted)}

/* ─── Mode pills ─── */
.mode-row{display:flex;gap:6px}
.mbtn{font-family:var(--fh);font-size:7px;letter-spacing:1px;padding:4px 12px;border:1px solid var(--border2);border-radius:2px;background:none;color:var(--muted);cursor:pointer;text-transform:uppercase}
.mbtn.paper.active{background:var(--yellow);color:#04080f;border-color:var(--yellow)}
.mbtn.live.active{background:var(--red);color:#fff;border-color:var(--red)}

/* ─── Scrollbar ─── */
::-webkit-scrollbar{width:3px}::-webkit-scrollbar-track{background:var(--bg)}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}

/* ─── Pending badge on tab ─── */
.badge{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:var(--red);color:#fff;font-size:9px;font-family:var(--fh);margin-left:4px;animation:pop .3s ease}
@keyframes pop{0%{transform:scale(0)}100%{transform:scale(1)}}

/* ─── OBI Gauge ─── */
.gauge-track{width:100%;height:10px;background:linear-gradient(90deg,var(--red2),#200810,var(--border),#081a10,var(--green2));border-radius:5px;position:relative;margin:8px 0;border:1px solid var(--border2)}
.gauge-thumb{position:absolute;top:50%;transform:translate(-50%,-50%);width:12px;height:16px;background:var(--text);border-radius:2px;transition:left .5s cubic-bezier(.4,0,.2,1)}
.gauge-labels{display:flex;justify-content:space-between;font-size:8px;color:var(--muted)}

/* Demo notification */
.demo-banner{background:rgba(255,214,10,.08);border:1px solid rgba(255,214,10,.3);border-radius:3px;padding:8px 12px;font-size:9px;color:var(--yellow);letter-spacing:1px;display:flex;align-items:center;gap:8px}
</style>
</head>
<body>
<div class="root">

<header>
  <div class="logo">
    <div class="hex"></div>
    <div class="logo-text">
      <h1>XRP GRID BOT</h1>
      <p>SEMI-AUTO · COINBASE ADVANCED · ORDER BOOK INTELLIGENCE</p>
    </div>
  </div>
  <div class="hdr-right">
    <div style="display:flex;align-items:center;gap:6px">
      <div class="live-dot" id="liveDot"></div>
      <span class="hdr-stat" id="statusTxt">CONNECTING</span>
    </div>
    <div>
      <div class="clock" id="clock">--:--:--</div>
      <div class="cbar"><div class="cfill" id="cfill" style="width:100%"></div></div>
    </div>
  </div>
</header>

<!-- Tabs -->
<div class="tabs">
  <div class="tab active" onclick="switchTab('signals')">⚡ SIGNALS <span id="pendingBadge" style="display:none" class="badge">0</span></div>
  <div class="tab" onclick="switchTab('market')">📈 MARKET</div>
  <div class="tab" onclick="switchTab('grid')">⚙️ GRID</div>
  <div class="tab" onclick="switchTab('portfolio')">💼 PORTFOLIO</div>
</div>

<!-- ══ SIGNALS TAB ══ -->
<div id="pane-signals" class="pane active">
  <div class="demo-banner" id="demoBanner">
    ✦ DEMO MODE — Signals below are simulated examples. Deploy to cloud and connect live market data to see real signals.
  </div>

  <!-- Metrics strip -->
  <div class="metrics">
    <div class="sig-mc" id="sigMc">
      <div class="sig-glow" id="sigGlow"></div>
      <div class="mc-label">MARKET SIGNAL</div>
      <div class="sig-txt" id="sigTxt">WAITING…</div>
    </div>
    <div class="mc"><div class="mc-label">PRICE</div><div class="mc-val" id="mcPrice">—</div><div class="mc-sub" id="mcPriceChg">—</div></div>
    <div class="mc"><div class="mc-label">BULL SCORE</div><div class="mc-val" id="mcBull">—</div><div class="mc-sub">0→1</div></div>
    <div class="mc"><div class="mc-label">OBI</div><div class="mc-val" id="mcObi" style="font-size:15px">—</div><div class="mc-sub">Imbalance</div></div>
    <div class="mc"><div class="mc-label">BOT STATUS</div><div class="mc-val" id="mcBotStatus" style="font-size:12px;color:var(--muted)">STOPPED</div><div class="mc-sub" id="mcMode">PAPER</div></div>
  </div>

  <!-- Signal queue -->
  <div class="panel">
    <div class="ptitle">PENDING SIGNALS — CONFIRM TO EXECUTE</div>
    <div class="signal-queue" id="signalQueue">
      <div class="no-signals" id="noSignals">
        <div class="pulse-ring"></div>
        Watching grid levels… signals appear here when price crosses a level.
      </div>
    </div>
  </div>
</div>

<!-- ══ MARKET TAB ══ -->
<div id="pane-market" class="pane">
  <div class="chart-row">
    <div class="panel">
      <div class="ptitle">PRICE · BID/ASK VWAP</div>
      <div class="chart-wrap"><canvas id="priceChart"></canvas></div>
    </div>
    <div class="panel">
      <div class="ptitle">OBI · BULL SCORE</div>
      <div class="chart-wrap"><canvas id="obiChart"></canvas></div>
    </div>
  </div>
  <div class="books">
    <div class="panel" style="overflow:auto;max-height:230px">
      <div class="ptitle">BIDS</div>
      <table class="ob-table"><thead><tr><th>Price</th><th>Qty XRP</th><th>Depth</th></tr></thead><tbody id="bidsBody"></tbody></table>
    </div>
    <div class="panel" style="overflow:auto;max-height:230px">
      <div class="ptitle">ASKS</div>
      <table class="ob-table"><thead><tr><th>Price</th><th>Qty XRP</th><th>Depth</th></tr></thead><tbody id="asksBody"></tbody></table>
    </div>
  </div>
  <div class="panel">
    <div class="ptitle">ORDER BOOK IMBALANCE</div>
    <div class="gauge-track"><div class="gauge-thumb" id="gaugeThumb" style="left:50%"></div></div>
    <div class="gauge-labels"><span style="color:var(--red)">SELL</span><span>NEUTRAL</span><span style="color:var(--green)">BUY</span></div>
  </div>
</div>

<!-- ══ GRID TAB ══ -->
<div id="pane-grid" class="pane">
  <!-- Bot toggle + mode -->
  <div class="panel">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">
      <div>
        <div class="ptitle">BOT CONTROL</div>
        <div class="tog-row">
          <label class="tog"><input type="checkbox" id="botToggle" onchange="toggleBot()"><div class="tog-sl"></div></label>
          <span class="tog-label" id="botLabel">BOT STOPPED</span>
        </div>
      </div>
      <div>
        <div class="ptitle">MODE</div>
        <div class="mode-row">
          <button class="mbtn paper active" id="modePaper" onclick="setMode('paper')">📝 PAPER</button>
          <button class="mbtn live" id="modeLive" onclick="setMode('live')">🔴 LIVE</button>
        </div>
      </div>
      <div style="font-size:9px;color:var(--muted)">
        Coinbase: <span id="cbStat" style="color:var(--red)">NOT CONNECTED</span>
      </div>
    </div>
  </div>

  <!-- Grid config -->
  <div class="panel">
    <div class="ptitle">GRID CONFIGURATION</div>
    <div class="cfg-grid">
      <div class="inp-group"><div class="inp-label">Upper Price (USD)</div><input class="inp" id="cfgUpper" type="number" step="0.01" value="2.50"/></div>
      <div class="inp-group"><div class="inp-label">Lower Price (USD)</div><input class="inp" id="cfgLower" type="number" step="0.01" value="1.80"/></div>
      <div class="inp-group"><div class="inp-label">Grid Levels</div><input class="inp" id="cfgLevels" type="number" step="1" min="2" max="50" value="10"/></div>
      <div class="inp-group"><div class="inp-label">Order Amount (USD)</div><input class="inp" id="cfgAmount" type="number" step="5" min="1" value="50"/></div>
      <div class="inp-group"><div class="inp-label">Stop Loss (%)</div><input class="inp" id="cfgStop" type="number" step="0.5" min="0" value="5"/></div>
      <div class="inp-group"><div class="inp-label">Take Profit (%)</div><input class="inp" id="cfgTP" type="number" step="0.5" min="0" value="15"/></div>
    </div>
    <div class="btn-row">
      <button class="btn btn-cyan" onclick="saveConfig()">💾 SAVE & APPLY</button>
      <button class="btn btn-outline" onclick="loadConfig()">↺ RELOAD</button>
    </div>
  </div>

  <!-- Grid visualizer -->
  <div class="panel">
    <div class="ptitle">GRID VISUALIZER <span id="gridPriceRange" style="float:right;color:var(--muted);font-size:8px"></span></div>
    <div class="grid-viz" id="gridViz">
      <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);font-size:9px">Configure grid above to see visualization</div>
    </div>
  </div>
</div>

<!-- ══ PORTFOLIO TAB ══ -->
<div id="pane-portfolio" class="pane">
  <div class="panel">
    <div class="ptitle">PORTFOLIO OVERVIEW</div>
    <div class="pnl-grid">
      <div class="pnl-c"><div class="pnl-label">CASH (USD)</div><div class="pnl-val" id="pfCash" style="color:var(--cyan)">—</div></div>
      <div class="pnl-c"><div class="pnl-label">XRP HELD</div><div class="pnl-val" id="pfXrp" style="color:var(--cyan)">—</div></div>
      <div class="pnl-c"><div class="pnl-label">XRP VALUE</div><div class="pnl-val" id="pfXrpVal" style="color:var(--cyan)">—</div></div>
      <div class="pnl-c"><div class="pnl-label">TOTAL VALUE</div><div class="pnl-val" id="pfTotal" style="color:var(--cyan)">—</div></div>
      <div class="pnl-c"><div class="pnl-label">UNREALIZED P&L</div><div class="pnl-val" id="pfUnreal">—</div></div>
      <div class="pnl-c"><div class="pnl-label">REALIZED P&L</div><div class="pnl-val" id="pfReal">—</div></div>
    </div>
    <div style="margin-top:10px;font-size:10px;color:var(--muted)">
      Avg Entry: <span id="pfAvg" style="color:var(--text)">—</span>
      &nbsp;·&nbsp; Current: <span id="pfCur" style="color:var(--cyan)">—</span>
    </div>
  </div>
  <div class="panel">
    <div class="ptitle">TRADE HISTORY <span id="tradeCount" style="float:right;color:var(--muted)"></span></div>
    <div class="tlog" id="tradeLog">
      <div style="text-align:center;padding:24px;color:var(--muted);font-size:9px">No trades yet</div>
    </div>
  </div>
</div>

</div><!-- root -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js"></script>
<script>
const API  = '';
const POLL = 15000;
const MXPT = 80;

let pChart, oChart, prevPrice=null, cdTimer, cdVal=POLL/1000;
let priceH=[], labelH=[];
let demoMode = true; // will flip to false when real data arrives

// ── Demo seed data ──────────────────────────────────────────────────────────
const DEMO_SIGNALS = [
  {
    id:'demo-001', side:'BUY', price:2.1840, xrp_qty:22.89, usd_amount:50.00,
    level_idx:2, level_label:'Level 3 of 10', level_low:2.1700, level_high:2.2400,
    stop_price:2.0748, target_price:2.5116, confidence:'HIGH', conf_color:'#00e87a',
    obi:0.22, bull_score:0.71, signal:'BUY', signal_color:'#44cc77',
    ts: new Date(Date.now()-45000).toISOString(), status:'pending', mode:'paper'
  },
  {
    id:'demo-002', side:'SELL', price:2.3800, xrp_qty:21.01, usd_amount:50.00,
    level_idx:5, level_label:'Level 6 of 10', level_low:2.3100, level_high:2.3800,
    stop_price:2.2610, target_price:2.7370, confidence:'MEDIUM', conf_color:'#ffd60a',
    obi:-0.08, bull_score:0.44, signal:'HOLD', signal_color:'#ffd60a',
    ts: new Date(Date.now()-12000).toISOString(), status:'pending', mode:'paper'
  }
];
const DEMO_MARKET = {
  mid_price:2.2140, best_bid:2.2135, best_ask:2.2145, spread:0.0010, spread_pct:0.0045,
  obi:0.18, smooth_obi:0.14, bid_vol:48200, ask_vol:38100, bull_score:0.67,
  bid_vwap:2.2088, ask_vwap:2.2192,
  signal:'BUY', signal_color:'#44cc77',
  sources:['DEMO'],
  ts: new Date().toISOString(),
  top_bids:[
    {price:2.2135,qty:4200},{price:2.2130,qty:6800},{price:2.2120,qty:3100},
    {price:2.2110,qty:5500},{price:2.2100,qty:8200},{price:2.2090,qty:2900},
    {price:2.2080,qty:4100},{price:2.2070,qty:3600}
  ],
  top_asks:[
    {price:2.2145,qty:3800},{price:2.2150,qty:5200},{price:2.2160,qty:4600},
    {price:2.2170,qty:6100},{price:2.2180,qty:3300},{price:2.2190,qty:4900},
    {price:2.2200,qty:7200},{price:2.2210,qty:2800}
  ]
};

// ── Tabs ──────────────────────────────────────────────────────────────────────
function switchTab(t) {
  document.querySelectorAll('.tab').forEach((el,i)=>el.classList.toggle('active',['signals','market','grid','portfolio'][i]===t));
  document.querySelectorAll('.pane').forEach(p=>p.classList.remove('active'));
  document.getElementById('pane-'+t).classList.add('active');
}

// ── Clock ──────────────────────────────────────────────────────────────────────
function tick() { document.getElementById('clock').textContent = new Date().toUTCString().split(' ')[4]+' UTC'; }
setInterval(tick,1000); tick();

function startCd() {
  cdVal=POLL/1000; clearInterval(cdTimer);
  cdTimer=setInterval(()=>{ cdVal=Math.max(0,cdVal-1); document.getElementById('cfill').style.width=(cdVal/(POLL/1000)*100)+'%'; },1000);
}

// ── Charts ─────────────────────────────────────────────────────────────────────
Chart.defaults.color='#3a5070'; Chart.defaults.font.family="'Share Tech Mono',monospace"; Chart.defaults.font.size=9;

function initCharts() {
  const pc=document.getElementById('priceChart').getContext('2d');
  const g=pc.createLinearGradient(0,0,0,160); g.addColorStop(0,'rgba(0,212,255,.18)'); g.addColorStop(1,'rgba(0,212,255,0)');
  pChart=new Chart(pc,{type:'line',data:{labels:[],datasets:[
    {label:'Price',data:[],borderColor:'#00d4ff',backgroundColor:g,borderWidth:2,pointRadius:1.5,tension:.3,fill:true},
    {label:'Bid VWAP',data:[],borderColor:'rgba(0,232,122,.4)',borderWidth:1,borderDash:[3,3],pointRadius:0,tension:.3,fill:false},
    {label:'Ask VWAP',data:[],borderColor:'rgba(255,45,85,.4)',borderWidth:1,borderDash:[3,3],pointRadius:0,tension:.3,fill:false},
    {label:'Buy',data:[],type:'scatter',backgroundColor:'rgba(0,232,122,.9)',pointRadius:6,pointStyle:'triangle',showLine:false},
    {label:'Sell',data:[],type:'scatter',backgroundColor:'rgba(255,45,85,.9)',pointRadius:6,pointStyle:'triangle',rotation:180,showLine:false},
  ]},options:{responsive:true,maintainAspectRatio:false,animation:{duration:350},interaction:{mode:'index',intersect:false},
    plugins:{legend:{display:true,position:'top',labels:{color:'#3a5070',boxWidth:8,padding:8,font:{size:8}}},
      tooltip:{backgroundColor:'#080d18',borderColor:'#22304a',borderWidth:1,callbacks:{label:c=>` ${c.dataset.label}: $${c.parsed.y?.toFixed(5)??'—'}`}}},
    scales:{x:{grid:{color:'#0c1422'},ticks:{maxTicksLimit:6,color:'#3a5070'}},
      y:{grid:{color:'#0c1422'},ticks:{color:'#3a5070',callback:v=>'$'+v.toFixed(4)}}}}});

  const oc=document.getElementById('obiChart').getContext('2d');
  oChart=new Chart(oc,{type:'bar',data:{labels:[],datasets:[
    {label:'OBI',data:[],backgroundColor:[],borderRadius:2,borderWidth:0},
    {label:'Bull',data:[],type:'line',borderColor:'#ffd60a',borderWidth:1.5,pointRadius:0,tension:.4,fill:false,yAxisID:'y2'},
  ]},options:{responsive:true,maintainAspectRatio:false,animation:{duration:300},
    plugins:{legend:{display:true,position:'top',labels:{color:'#3a5070',boxWidth:8,padding:8,font:{size:8}}},
      tooltip:{callbacks:{label:c=>` ${c.dataset.label}: ${c.parsed.y?.toFixed(4)}`}}},
    scales:{x:{display:false},y:{grid:{color:'#0c1422'},ticks:{color:'#3a5070',count:5},min:-1,max:1},
      y2:{position:'right',grid:{display:false},ticks:{color:'#ffd60a',count:5},min:0,max:1}}}});
}

function addToCharts(d, isBuySig, isSellSig) {
  const ts=new Date(d.ts).toUTCString().split(' ')[4];
  if(priceH.length>=MXPT){
    priceH.shift();labelH.shift();
    pChart.data.labels.shift(); pChart.data.datasets.forEach(ds=>ds.data.shift());
    oChart.data.labels.shift(); oChart.data.datasets[0].data.shift(); oChart.data.datasets[0].backgroundColor.shift(); oChart.data.datasets[1].data.shift();
  }
  priceH.push(d.mid_price); labelH.push(ts);
  pChart.data.labels.push(ts);
  pChart.data.datasets[0].data.push(d.mid_price);
  pChart.data.datasets[1].data.push(d.bid_vwap);
  pChart.data.datasets[2].data.push(d.ask_vwap);
  pChart.data.datasets[3].data.push(isBuySig?{x:ts,y:d.mid_price}:null);
  pChart.data.datasets[4].data.push(isSellSig?{x:ts,y:d.mid_price}:null);
  pChart.update('active');
  const bc=d.obi>.15?'rgba(0,232,122,.75)':d.obi<-.15?'rgba(255,45,85,.75)':'rgba(255,214,10,.55)';
  oChart.data.labels.push(ts); oChart.data.datasets[0].data.push(d.obi); oChart.data.datasets[0].backgroundColor.push(bc); oChart.data.datasets[1].data.push(d.bull_score);
  oChart.update('active');
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt  = (n,d=5)=>n!=null?Number(n).toFixed(d):'—';
const fmtU = n=>n!=null?'$'+Number(n).toFixed(2):'—';
const fmtK = n=>n>=1e6?(n/1e6).toFixed(2)+'M':n>=1e3?(n/1e3).toFixed(1)+'K':n?.toFixed(0)??'—';
const pc   = v=>v>0?'var(--green)':v<0?'var(--red)':'var(--muted)';

// ── Render market ─────────────────────────────────────────────────────────────
function renderMarket(d) {
  document.getElementById('sigTxt').textContent=d.signal;
  document.getElementById('sigTxt').style.color=d.signal_color;
  document.getElementById('sigGlow').style.background=d.signal_color;
  document.getElementById('sigMc').style.borderColor=d.signal_color+'44';
  const mp=document.getElementById('mcPrice'); mp.textContent='$'+fmt(d.mid_price);
  if(prevPrice!=null){
    const df=d.mid_price-prevPrice,p=prevPrice?((df/prevPrice)*100).toFixed(4):0;
    const el=document.getElementById('mcPriceChg');
    el.textContent=(df>=0?'▲ +':'▼ ')+fmt(df,5)+'  ('+p+'%)';
    el.style.color=mp.style.color=df>=0?'var(--green)':'var(--red)';
  }
  prevPrice=d.mid_price;
  const bs=d.bull_score,bsEl=document.getElementById('mcBull');
  bsEl.textContent=fmt(bs,3); bsEl.style.color=bs>.6?'var(--green)':bs<.4?'var(--red)':'var(--yellow)';
  const ov=document.getElementById('mcObi'); ov.textContent=(d.obi>=0?'+':'')+fmt(d.obi,4);
  ov.style.color=d.obi>0?'var(--green)':d.obi<0?'var(--red)':'var(--text)';
  document.getElementById('gaugeThumb').style.left=((d.obi+1)/2*100).toFixed(1)+'%';
  renderBook(d.top_bids||[],d.top_asks||[]);
}

function renderBook(bids,asks){
  const mx=Math.max(...bids.map(b=>b.qty),...asks.map(a=>a.qty),1);
  const rows=(ords,cls,col)=>ords.map(o=>{
    const bw=(o.qty/mx*100).toFixed(1);
    return `<tr class="ob-${cls}"><td>$${Number(o.price).toFixed(5)}</td><td>${fmtK(o.qty)}</td>
    <td style="position:relative;min-width:42px"><div class="dbar" style="width:${bw}%;background:${col}"></div>${bw}%</td></tr>`;
  }).join('');
  document.getElementById('bidsBody').innerHTML=rows(bids,'bid','var(--green)');
  document.getElementById('asksBody').innerHTML=rows(asks,'ask','var(--red)');
}

// ── Render signal queue ────────────────────────────────────────────────────────
function renderSignals(signals) {
  const el=document.getElementById('signalQueue');
  const noEl=document.getElementById('noSignals');
  const badge=document.getElementById('pendingBadge');
  if(!signals||!signals.length){
    noEl.style.display='block'; badge.style.display='none';
    el.innerHTML=''; el.appendChild(noEl); return;
  }
  noEl.style.display='none';
  badge.textContent=signals.length; badge.style.display='inline-flex';
  el.innerHTML=signals.map(s=>{
    const isBuy=s.side==='BUY';
    const age=Math.floor((Date.now()-new Date(s.ts).getTime())/1000);
    const ageStr=age<60?age+'s ago':Math.floor(age/60)+'m ago';
    return `<div class="signal-card ${s.side.toLowerCase()}" id="sc-${s.id}">
      <div class="sc-header">
        <div>
          <span class="sc-badge ${s.side.toLowerCase()}">${isBuy?'⬆ BUY':'⬇ SELL'}</span>
          <span class="sc-level" style="margin-left:8px">${s.level_label}</span>
        </div>
        <span style="font-size:8px;color:var(--muted)">${ageStr} · ${s.mode.toUpperCase()}</span>
      </div>
      <div class="sc-price ${s.side.toLowerCase()}">$${fmt(s.price,5)}</div>
      <div class="sc-details">
        <div class="sc-detail"><div class="sc-detail-label">XRP Amount</div><div class="sc-detail-val">${fmt(s.xrp_qty,4)} XRP</div></div>
        <div class="sc-detail"><div class="sc-detail-label">USD Value</div><div class="sc-detail-val">${fmtU(s.usd_amount)}</div></div>
        <div class="sc-detail"><div class="sc-detail-label">${isBuy?'Stop Loss':'Level Low'}</div><div class="sc-detail-val" style="color:var(--red)">$${fmt(s.stop_price,5)}</div></div>
        <div class="sc-detail"><div class="sc-detail-label">${isBuy?'Take Profit':'Level High'}</div><div class="sc-detail-val" style="color:var(--green)">$${fmt(s.target_price,5)}</div></div>
        <div class="sc-detail"><div class="sc-detail-label">Grid Zone</div><div class="sc-detail-val" style="font-size:10px">$${fmt(s.level_low,5)} – $${fmt(s.level_high,5)}</div></div>
        <div class="sc-detail"><div class="sc-detail-label">Market Signal</div><div class="sc-detail-val" style="color:${s.signal_color}">${s.signal}</div></div>
      </div>
      <div class="sc-obi-row">
        <span style="font-size:9px;color:var(--muted)">OBI: <span style="color:${s.obi>0?'var(--green)':'var(--red)'}">${s.obi>=0?'+':''}${fmt(s.obi,4)}</span></span>
        <span style="font-size:9px;color:var(--muted)">Bull Score: <span style="color:${s.bull_score>.6?'var(--green)':s.bull_score<.4?'var(--red)':'var(--yellow)'}">${fmt(s.bull_score,3)}</span></span>
        <span class="sc-conf-badge" style="background:${s.conf_color}22;color:${s.conf_color};border:1px solid ${s.conf_color}88">CONFIDENCE: ${s.confidence}</span>
      </div>
      <div class="sc-actions">
        <button class="btn-confirm ${isBuy?'':'sell-confirm'}" onclick="confirmSignal('${s.id}')">
          ✅ CONFIRM ${isBuy?'BUY':'SELL'}
        </button>
        <button class="btn-skip" onclick="skipSignal('${s.id}')">❌ SKIP</button>
      </div>
    </div>`;
  }).join('');
}

// ── Render grid visualizer ────────────────────────────────────────────────────
function renderGridViz(state) {
  const el=document.getElementById('gridViz');
  const lines=state.grid_lines||[];
  if(!lines.length){el.innerHTML='<div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--muted);font-size:9px">Configure grid above</div>';return;}
  const prices=lines.map(l=>l.price);
  const minP=Math.min(...prices), maxP=Math.max(...prices), rangeP=maxP-minP||1;
  const curP=state.market?.mid_price||0;
  document.getElementById('gridPriceRange').textContent=`$${fmt(minP,4)} — $${fmt(maxP,4)}`;
  let html='';
  lines.forEach(l=>{
    const topPct=100-((l.price-minP)/rangeP*100);
    const hasBuy=l.has_buy,hasSell=l.has_sell;
    const cls=hasBuy?'has-buy':hasSell?'has-sell':'';
    html+=`<div class="grid-line" style="top:${topPct}%"></div>
    <div class="grid-line-label ${cls}" style="top:${topPct}%">${hasBuy?'🟢':hasSell?'🔴':'·'} $${fmt(l.price,5)}</div>`;
  });
  // Price cursor
  if(curP>=minP&&curP<=maxP){
    const curTop=100-((curP-minP)/rangeP*100);
    html+=`<div class="price-cursor" style="top:${curTop}%"></div>
    <div class="price-tag" style="top:${curTop}%">$${fmt(curP,5)}</div>`;
  }
  el.innerHTML=html;
}

// ── Render portfolio ──────────────────────────────────────────────────────────
function renderPortfolio(pf) {
  if(!pf) return;
  document.getElementById('pfCash').textContent  = fmtU(pf.cash_usd);
  document.getElementById('pfXrp').textContent   = fmt(pf.xrp_held,4)+' XRP';
  document.getElementById('pfXrpVal').textContent= fmtU(pf.xrp_value_usd);
  document.getElementById('pfTotal').textContent = fmtU(pf.total_value);
  const ur=pf.unrealized_pnl,re=pf.realized_pnl;
  document.getElementById('pfUnreal').textContent=(ur>=0?'+':'')+fmtU(ur); document.getElementById('pfUnreal').style.color=pc(ur);
  document.getElementById('pfReal').textContent  =(re>=0?'+':'')+fmtU(re); document.getElementById('pfReal').style.color=pc(re);
  document.getElementById('pfAvg').textContent   = pf.avg_entry?'$'+fmt(pf.avg_entry,5):'—';
  document.getElementById('pfCur').textContent   = pf.current_price?'$'+fmt(pf.current_price,5):'—';
}

function renderTradeLog(trades) {
  document.getElementById('tradeCount').textContent=trades.length+' trades';
  document.getElementById('tradeLog').innerHTML=trades.length?trades.map(t=>{
    const pnl=t.pnl!=null?(t.pnl>=0?`<span style="color:var(--green)">+$${Math.abs(t.pnl).toFixed(4)}</span>`:`<span style="color:var(--red)">-$${Math.abs(t.pnl).toFixed(4)}</span>`):'';
    return `<div class="trow">
      <span class="tbadge t${t.side.toLowerCase()}">${t.side}</span>
      <span style="color:var(--cyan)">$${fmt(t.price,5)}</span>
      <span class="tmeta">${fmt(t.xrp_qty,4)} XRP · ${fmtU(t.usd_amount)}</span>
      <span class="tmeta">${t.level_label||'—'}</span>
      ${pnl}
      <span class="tmeta" style="margin-left:auto">${t.mode||'paper'}</span>
    </div>`;
  }).join(''):'<div style="text-align:center;padding:24px;color:var(--muted);font-size:9px">No trades yet</div>';
}

function renderBotStatus(s) {
  document.getElementById('botToggle').checked=s.running;
  document.getElementById('botLabel').textContent=s.running?'🟢 BOT WATCHING':'⭕ BOT STOPPED';
  document.getElementById('botLabel').style.color=s.running?'var(--green)':'var(--muted)';
  document.getElementById('mcBotStatus').textContent=s.running?'WATCHING':'STOPPED';
  document.getElementById('mcBotStatus').style.color=s.running?'var(--green)':'var(--muted)';
  document.getElementById('mcMode').textContent=s.mode.toUpperCase();
  document.getElementById('modePaper').classList.toggle('active',s.mode==='paper');
  document.getElementById('modeLive').classList.toggle('active',s.mode==='live');
  const cb=document.getElementById('cbStat');
  cb.textContent=s.cb_connected?'CONNECTED ✓':'NOT CONNECTED';
  cb.style.color=s.cb_connected?'var(--green)':'var(--red)';
}

// ── Actions ───────────────────────────────────────────────────────────────────
function toggleBot(){
  const on=document.getElementById('botToggle').checked;
  if(demoMode){alert('Deploy to cloud to enable live bot watching. Currently showing demo signals.');document.getElementById('botToggle').checked=false;return;}
  fetch(API+(on?'/api/bot/start':'/api/bot/stop'),{method:'POST'}).then(()=>fetchState());
}

function setMode(m){
  if(demoMode){alert('Deploy to cloud to switch modes.');return;}
  fetch(API+'/api/bot/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:m})}).then(()=>fetchState());
}

function saveConfig(){
  const cfg={upper:+document.getElementById('cfgUpper').value,lower:+document.getElementById('cfgLower').value,
    levels:+document.getElementById('cfgLevels').value,amount_usd:+document.getElementById('cfgAmount').value,
    stop_loss_pct:+document.getElementById('cfgStop').value,take_profit_pct:+document.getElementById('cfgTP').value};
  if(cfg.upper<=cfg.lower){alert('Upper price must be greater than lower price.');return;}
  if(demoMode){
    // Update demo viz
    const lines=[];
    const step=(cfg.upper-cfg.lower)/cfg.levels;
    for(let i=0;i<=cfg.levels;i++) lines.push({index:i,price:+(cfg.lower+i*step).toFixed(6),has_buy:false,has_sell:false});
    renderGridViz({grid_lines:lines,market:DEMO_MARKET,config:cfg});
    return;
  }
  fetch(API+'/api/bot/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({config:cfg})}).then(()=>fetchState());
}

function loadConfig(){
  if(demoMode) return;
  fetchState();
}

function confirmSignal(id){
  if(demoMode){
    // Demo confirm — animate and remove card
    const card=document.getElementById('sc-'+id);
    if(card){card.style.opacity='0';card.style.transform='translateX(40px)';card.style.transition='all .3s';
      setTimeout(()=>{
        const sigs=DEMO_SIGNALS.filter(s=>s.id!==id);
        DEMO_SIGNALS.length=0; sigs.forEach(s=>DEMO_SIGNALS.push(s));
        renderSignals(DEMO_SIGNALS);
        // Show success toast
        showToast('✅ DEMO TRADE EXECUTED — Deploy to cloud for real trades','var(--green)');
      },300);
    }
    return;
  }
  fetch(API+'/api/bot/confirm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({signal_id:id})})
    .then(r=>r.json()).then(r=>{showToast(r.ok?'✅ Trade executed!':'❌ '+(r.error||'Failed'),r.ok?'var(--green)':'var(--red)');fetchState();});
}

function skipSignal(id){
  if(demoMode){
    const card=document.getElementById('sc-'+id);
    if(card){card.style.opacity='0';card.style.transition='opacity .3s';
      setTimeout(()=>{const sigs=DEMO_SIGNALS.filter(s=>s.id!==id);DEMO_SIGNALS.length=0;sigs.forEach(s=>DEMO_SIGNALS.push(s));renderSignals(DEMO_SIGNALS);},300);
    }
    return;
  }
  fetch(API+'/api/bot/skip',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({signal_id:id})}).then(()=>fetchState());
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function showToast(msg,color){
  const t=document.createElement('div');
  t.style.cssText=`position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:${color};color:#04080f;padding:10px 20px;border-radius:4px;font-family:var(--fh);font-size:10px;letter-spacing:2px;z-index:9999;animation:pop .3s ease`;
  t.textContent=msg; document.body.appendChild(t); setTimeout(()=>t.remove(),3000);
}

// ── Fetch ─────────────────────────────────────────────────────────────────────
function setStatus(live,txt){
  document.getElementById('liveDot').className='live-dot'+(live?' on':'');
  document.getElementById('statusTxt').textContent=txt;
}

async function fetchState(){
  try{
    const s=await fetch(API+'/api/bot/state',{cache:'no-store'}).then(r=>r.json());
    demoMode=false;
    document.getElementById('demoBanner').style.display='none';
    renderSignals(s.pending||[]);
    renderGridViz(s);
    renderPortfolio(s.portfolio);
    renderTradeLog(s.trade_log||[]);
    renderBotStatus(s);
    if(s.config){
      document.getElementById('cfgUpper').value=s.config.upper||2.50;
      document.getElementById('cfgLower').value=s.config.lower||1.80;
      document.getElementById('cfgLevels').value=s.config.levels||10;
      document.getElementById('cfgAmount').value=s.config.amount_usd||50;
      document.getElementById('cfgStop').value=s.config.stop_loss_pct||5;
      document.getElementById('cfgTP').value=s.config.take_profit_pct||15;
    }
  }catch(e){
    // Stay in demo mode
  }
}

async function fetchMarket(){
  try{
    const d=await fetch(API+'/api/latest',{cache:'no-store'}).then(r=>r.json());
    if(!d?.mid_price) throw new Error();
    demoMode=false;
    setStatus(true,'LIVE · XRPL + BINANCE');
    renderMarket(d);
    const isBuy=d.signal==='BUY'||d.signal==='STRONG BUY';
    const isSell=d.signal==='SELL'||d.signal==='STRONG SELL';
    addToCharts(d,isBuy,isSell);
    startCd();
    fetchState();
  }catch{
    setStatus(false, demoMode?'DEMO MODE':'CONNECTING…');
  }
}

async function seedHistory(){
  // Seed demo chart data
  if(demoMode){
    const base=2.18,now=Date.now();
    for(let i=MXPT;i>=0;i--){
      const t=new Date(now-i*15000); const p=base+Math.sin(i*.18)*.06+Math.random()*.02;
      const ts=t.toUTCString().split(' ')[4];
      priceH.push(p); labelH.push(ts);
      pChart.data.labels.push(ts); pChart.data.datasets[0].data.push(p);
      pChart.data.datasets[1].data.push(p-.005); pChart.data.datasets[2].data.push(p+.005);
      pChart.data.datasets[3].data.push(i%22===0?{x:ts,y:p}:null);
      pChart.data.datasets[4].data.push(i%31===0?{x:ts,y:p}:null);
      const obi=(Math.random()-.45)*.4;
      const bc=obi>.15?'rgba(0,232,122,.75)':obi<-.15?'rgba(255,45,85,.75)':'rgba(255,214,10,.55)';
      oChart.data.labels.push(ts); oChart.data.datasets[0].data.push(obi); oChart.data.datasets[0].backgroundColor.push(bc);
      oChart.data.datasets[1].data.push(.4+Math.random()*.35);
    }
    pChart.update(); oChart.update();
    renderMarket(DEMO_MARKET);
    renderBook(DEMO_MARKET.top_bids,DEMO_MARKET.top_asks);
  } else {
    try{
      const hist=await fetch(API+'/api/history',{cache:'no-store'}).then(r=>r.json());
      if(!Array.isArray(hist)||!hist.length) return;
      for(const d of hist.slice(-MXPT)) addToCharts(d,false,false);
      pChart.update(); oChart.update();
    }catch(e){}
  }
}

// ── Init ──────────────────────────────────────────────────────────────────────
initCharts();

// Show demo signals immediately
renderSignals(DEMO_SIGNALS);
renderPortfolio({cash_usd:1000,xrp_held:0,avg_entry:0,realized_pnl:0,xrp_value_usd:0,total_value:1000,unrealized_pnl:0,current_price:0});

// Try to connect to real server
fetchState();
fetchMarket().then(()=>{ seedHistory(); });
seedHistory();

setInterval(()=>{ fetchMarket(); fetchState(); }, POLL);
</script>
</body>
</html>"""

# ─── HTTP Handler ─────────────────────────────────────────────────────────────
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path=self.path.split("?")[0]
        if path in ("/",""):
            self._send(200,"text/html; charset=utf-8",DASHBOARD_HTML.encode())
        elif path=="/api/latest":
            with state_lock: self._json(latest_snapshot)
        elif path=="/api/history":
            with state_lock: self._json(list(history))
        elif path=="/api/bot/state":
            self._json(full_state())
        elif path=="/health":
            self._json({"ok":True,"running":grid["running"],"mode":grid["mode"]})
        else:
            self._send(404,"text/plain",b"Not found")

    def do_POST(self):
        path=self.path.split("?")[0]
        n=int(self.headers.get("Content-Length",0))
        body=json.loads(self.rfile.read(n)) if n else {}
        if path=="/api/bot/start":
            with grid_lock: grid["running"]=True
            log.info("Bot STARTED"); self._json({"ok":True})
        elif path=="/api/bot/stop":
            with grid_lock: grid["running"]=False
            log.info("Bot STOPPED"); self._json({"ok":True})
        elif path=="/api/bot/config":
            with grid_lock:
                if "config" in body: grid["config"].update(body["config"]); recompute_grid()
                if "mode" in body:
                    if body["mode"]=="live" and not CB_API_KEY:
                        self._json({"ok":False,"error":"No Coinbase API keys"}); return
                    grid["mode"]=body["mode"]
            self._json({"ok":True})
        elif path=="/api/bot/confirm":
            ok,msg=confirm_signal(body.get("signal_id",""))
            self._json({"ok":ok,"msg":msg})
        elif path=="/api/bot/skip":
            ok=skip_signal(body.get("signal_id",""))
            self._json({"ok":ok})
        else:
            self._send(404,"text/plain",b"Not found")

    def _json(self,data):
        self._send(200,"application/json",json.dumps(data).encode())

    def _send(self,code,ct,body):
        self.send_response(code)
        self.send_header("Content-Type",ct)
        self.send_header("Content-Length",len(body))
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Cache-Control","no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self,*_): pass

def run_http():
    srv=HTTPServer(("0.0.0.0",PORT),Handler)
    log.info(f"HTTP on :{PORT}  mode={grid['mode']}  CB={'SET' if CB_API_KEY else 'NOT SET'}")
    srv.serve_forever()

if __name__=="__main__":
    recompute_grid()
    threading.Thread(target=run_http,daemon=True).start()
    log.info("XRP Semi-Auto Grid Bot — starting")
    asyncio.run(poll_loop())
